import React from "react";
import { View, Text, StyleSheet, TextInput, Button, Alert } from "react-native";
import { Ionicons } from '@expo/vector-icons';


export default class Header extends React.Component {
    
    render() {
        return (
            <View style={styles.header}>
                <View style={styles.firstRow}>
                    <Ionicons style={styles.iconLeft}name="ios-menu" size={32}/>
                    <Text style={styles.appTitle}>Greener Apps</Text>
                    <Ionicons style={styles.iconRight}name="ios-information-circle-outline" size={32}/>
                </View>
                <TextInput style={styles.textImput} placeholder="HALPS" />
                <Button title="Press me" onPress={() => Alert.alert('Simple Button pressed')}/>
            </View>
          );
    }
  }

  const styles = StyleSheet.create({
      header: {
            backgroundColor: '#FFF',
            width: '100%',
            height: 200,
            display: 'flex',
            alignItems: "center",
            borderBottomColor: '#000',
            borderBottomWidth: 2
        },
        firstRow: {
            display: 'flex',
            alignItems: "center",
            flexDirection: 'row',
        },
        appTitle: {
            paddingTop: 0,
            textAlign: 'center',
            color: '#2CBC52',
            fontSize: 30,
        }, 
        iconLeft: {
            color: 'black',
            paddingLeft: 20,
            paddingRight: 30
        },
        iconRight: {
            color: 'black',
            paddingRight: 20,
            paddingLeft: 30
        }, 
        textImput: {
            height: 40,
            backgroundColor: 'black'
        }
  })